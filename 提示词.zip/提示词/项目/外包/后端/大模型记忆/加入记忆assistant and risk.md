### 先给你结论

这次最适合直接交给 Codex（代码智能体）的，不是“泛泛做记忆”，而是：

**只改后端，在现有 `/api/v1/assistant` 链路上补一层“短期会话记忆 + 长期用户摘要 + 最近风险事件回忆”，并保持前端不改、旧接口可兼容。**

这样最符合你当前项目定位：现有系统已经有 `POST /api/v1/assistant`，数据库里也已经预留了 `user_profile.memory_summary`，同时 `risk_event / risk_input_record / risk_analysis_result` 这些表本身就适合承载“事件型记忆”；方案文档也明确要求“实现对话历史存储与检索”，并强调“知识检索增强（RAG，Retrieval-Augmented Generation，检索增强生成）”与个性化风险评估。

------

### 只改后端的 Codex 提示词

下面这份可以直接丢给 Codex。

```text
你现在进入“强约束后端最小侵入改造模式”。

任务目标：
为当前反诈项目的后端问答链路加入“按用户上下文产生记忆效果”的能力，但只允许修改后端与 model-service，不允许修改前端页面代码。目标是在现有 `/api/v1/assistant` 基础上，实现：
1. 短期会话记忆（最近若干轮对话）
2. 长期用户记忆（复用 user_profile.memory_summary）
3. 最近风险事件记忆（复用 risk_event / risk_input_record / risk_analysis_result）
4. 保持旧接口兼容：前端即使不传新字段，也仍可正常调用

项目背景约束：
- 当前系统已有 `/api/v1/assistant`
- 当前 assistant 链路是：endpoint -> AssistantService -> ModelGateway -> model-service `/runtime/assistant`
- 当前问答基本是“无记忆一次性问答”
- 数据库里已有 `user_profile.memory_summary`
- 数据库里已有 `risk_event`、`risk_input_record`、`risk_analysis_result`
- 现有产品方向强调：
  - 用户主动触发问答
  - 知识检索增强（RAG）
  - 个性化风险评估
  - 对话历史存储与检索
- V1 不引入新的前端改造，不要求上线向量数据库，不要求重构成复杂 Agent（智能体）框架
- 先用 SQLite + SQLAlchemy 跑通最小闭环
- 代码要求简洁、可读、最小侵入，避免多余抽象

硬性范围限制：
- 只允许修改：
  - backend/
  - model-service/
- 不允许修改：
  - frontend/
- 不允许破坏现有 `/api/v1/analysis`、`/api/v1/incidents`、页面聚合接口、现有测试主链
- 不允许删除现有 heuristic fallback（启发式兜底）逻辑
- 不允许把大量历史全文无上限塞给模型，必须做“限量 + 摘要”
- 不允许引入重量级新依赖，除非绝对必要
- 不允许为了“记忆”而保存敏感原始信息（如验证码、完整银行卡号、身份证全号等）；如涉及存储，需做基础脱敏
- 所有新增代码必须带类型标注
- 所有变更必须保证旧请求体仍可工作

实现要求：
一、扩展 assistant 请求体，但保持兼容
在 `backend/app/schemas/assistant.py` 中扩展 `AssistantRequest`：
- 保留：
  - question
  - persona
- 新增可选字段：
  - user_id: int | None
  - session_id: str | None
  - use_memory: bool = True
  - incident_id: str | None
- 原有前端若只传 `question/persona`，接口仍可正常返回
- `AssistantResponse` 尽量保持兼容；如需新增字段，只能新增非破坏性字段，例如：
  - memory_used: bool
  - session_id: str | None

二、新增最小会话记忆表
在 backend SQLAlchemy 模型中新增两张表：
1. `assistant_session`
   - id
   - user_id
   - session_id（唯一）
   - title
   - last_active_at
   - created_at
   - updated_at
2. `assistant_message`
   - id
   - session_id（外键指向 assistant_session.id 或逻辑关联字段，任选一种但要统一）
   - role（user / assistant / system / summary）
   - content
   - content_type（text / summary / incident_context）
   - created_at

要求：
- 复用项目现有 Base、IdType、TimestampMixin 风格
- 更新 `backend/app/models/__init__.py`
- 更新 `backend/app/models/entities.py`（如果当前项目通过它集中导出）
- 确保 `init_db()` 能自动建表

三、新增 MemoryRepository 与 MemoryService
新增：
- `backend/app/repositories/assistant_memory_repository.py`
- `backend/app/services/memory_service.py`

MemoryRepository 负责：
1. 创建/获取 session
2. 写入消息
3. 读取最近 N 条会话消息（默认 6~8 条）
4. 读取用户画像摘要：
   - user_profile.memory_summary
   - role_type
   - risk_preference
   - protection_mode
   - fraud_focus_type
5. 读取最近风险事件摘要：
   - 从 risk_event 取最近事件
   - 从 risk_input_record 取相关输入文本（original_content / transcript_text / ocr_text）
   - 从 risk_analysis_result 取 analysis_summary / decision_reason / final_label / similarity_case_ids / law_ref_ids
6. 提供基础脱敏函数：
   - 对验证码、长数字串做 mask
   - 避免把明显敏感文本直接长期存入 message 或 summary

MemoryService 负责：
1. `build_context(...)`
   输入：
   - user_id
   - session_id
   - question
   - persona
   - incident_id
   - use_memory
   输出结构建议：
   {
     "profile_summary": str,
     "recent_dialogue": list[{"role": "...", "content": "..."}],
     "recent_incidents": list[str],
     "retrieved_case_hints": list[str],
     "memory_enabled": bool,
   }

2. `append_user_message(...)`
3. `append_assistant_message(...)`
4. `maybe_update_profile_summary(...)`
   - 不做复杂 LLM 总结，可先采用规则摘要：
     - 统计最近高频诈骗类型
     - 汇总近期高风险事件数
     - 合并 user_profile 中已有 role/protection 配置
   - 将结果写回 `user_profile.memory_summary`
   - 保持实现简单、稳定、可复现

四、改造 AssistantService
修改 `backend/app/services/assistant_service.py`：
- 不再直接 `model_gateway.answer(question, persona)`
- 新流程：
  1. 先根据 payload 构建 memory_context
  2. 把 memory_context 传给 model_gateway.answer(...)
  3. 获取结果后写入 assistant_message
  4. 视情况更新 user_profile.memory_summary
  5. 继续保留现有 knowledge_service.build_assistant_references(...) 逻辑
- 如果 `use_memory=False` 或缺失 `user_id/session_id`，则自动降级为无记忆模式，但接口仍可用
- 如果 session_id 为空而 user_id 存在，可自动创建 session_id（uuid）

五、改造 ModelGateway
修改 `backend/app/services/model_gateway.py`：
- 扩展 `answer()` 签名：
  - question
  - persona
  - memory_context: dict[str, object] | None = None
- 调用 model-service `/runtime/assistant` 时，一并传：
  - question
  - persona
  - memory_context
- 若远端失败，fallback 仍然保留
- fallback 模式下：
  - 可以忽略 memory_context
  - 但不要报错
- 不改变 classify 主链行为

六、改造 model-service schema 与 runtime
修改：
- `model-service/app/schemas.py`
- `model-service/app/api/v1/endpoints/runtime.py`
- `model-service/app/services/multimodal_inference_service.py`
- `model-service/app/services/model_runtime.py`

要求：
1. 扩展 `RuntimeAssistantRequest`
   - question
   - persona
   - memory_context: dict[str, Any] = Field(default_factory=dict)

2. `answer_text(...)` 允许传入 memory_context

3. `ModelBackend` 协议同步改造：
   - answer(self, question: str, persona: str, memory_context: dict[str, object] | None = None) -> dict[str, str]

4. `HeuristicModelBackend.answer(...)`
   - 忽略 memory_context，但签名保持一致

5. `PromptModelBackend.answer(...)`
   - 把 memory_context 编织进 prompt
   - 必须限制长度，避免 prompt 爆炸
   - 最近对话只取最后几轮
   - recent_incidents 只取最近 2~3 条
   - profile_summary 控制在短文本范围
   - prompt 输出要求：
     - 先给风险判断
     - 再给 2~4 条建议
     - 若历史事件相似，可指出“与近期某次风险场景相似”
     - 不得编造未提供的事实
   - 若 memory_context 为空，也能正常回答

七、知识与历史的关系
- 当前知识库检索逻辑保持在 backend 的 `KnowledgeService`
- 不要把知识库检索搬到 model-service
- model-service 只负责“根据 question + memory_context 生成回答”
- backend 继续负责 references / knowledge_meta 拼装

八、需要补充的测试
新增或修改 backend 测试，至少覆盖：
1. 旧请求兼容测试
   - 只传 question/persona 仍可正常调用 `/api/v1/assistant`

2. 新请求字段测试
   - 传 user_id/session_id/use_memory 后可正常返回

3. 会话落库测试
   - 问答后 assistant_session / assistant_message 有记录

4. 无记忆降级测试
   - use_memory=False 时仍可正常回答

5. 远端失败兜底测试
   - model-service 不可用时，assistant 接口仍可返回 heuristic fallback 结果

6. 记忆摘要更新测试
   - 多轮问答后可更新 `user_profile.memory_summary`（至少验证非空或包含预期关键词）

九、代码风格要求
- 优先最小侵入，不搞大重构
- 复用现有 repository/service/dependencies 风格
- 新增依赖注入函数到 `backend/app/dependencies.py`
- 不要引入神秘魔法层，不要过度抽象
- 所有新增函数写清楚 docstring（文档字符串）或注释，说明用途
- 所有 import 整理干净
- 所有新增文件接入现有包结构

十、输出要求
请直接完成代码修改，并同时给出：
1. 修改/新增的文件清单
2. 每个文件改动目的
3. 数据流说明（从 `/api/v1/assistant` 到 model-service 再回写 memory）
4. 运行与验证步骤
5. 若某处设计与你发现的现有代码结构冲突，请以“最小兼容”为第一原则调整，但不要擅自改前端

额外强调：
- 这是 V1，会话记忆优先，向量记忆以后再扩展
- V1 不要求 PostgreSQL + pgvector 真正接入
- V1 允许只做“最近会话 + user_profile.memory_summary + 最近风险事件摘要”
- 目标是先跑通、可测试、可解释、可继续迭代
```

------

### 需要新增/修改的文件清单

下面这份是按你**当前仓库结构**整理的，尽量按“必改 / 建议新增 / 可能联动”来分。

------

### 必改文件

| 文件                                                         | 为什么要改                                        | 改什么                                                       |
| ------------------------------------------------------------ | ------------------------------------------------- | ------------------------------------------------------------ |
| `backend/app/schemas/assistant.py`                           | 现在请求体太短，只能无记忆问答                    | 给 `AssistantRequest` 增加 `user_id / session_id / use_memory / incident_id`，响应体可选增加 `memory_used / session_id` |
| `backend/app/services/assistant_service.py`                  | 当前只是直接把 question 扔给模型                  | 改成“先取记忆 -> 调模型 -> 回写消息/摘要 -> 拼 references”   |
| `backend/app/services/model_gateway.py`                      | 当前 `answer()` 不接收记忆上下文                  | 扩展 `memory_context` 入参并透传给 model-service，保留 fallback |
| `backend/app/dependencies.py`                                | 需要把新仓储和服务接到依赖注入里                  | 新增 `get_assistant_memory_repository()`、`get_memory_service()`，并改造 `get_assistant_service()` |
| `model-service/app/schemas.py`                               | 当前 `/runtime/assistant` 只有 `question/persona` | 给 `RuntimeAssistantRequest` 增加 `memory_context`           |
| `model-service/app/api/v1/endpoints/runtime.py`              | 需要把后端传来的 `memory_context` 接进去          | 改 `assistant()` 路由调用签名                                |
| `model-service/app/services/multimodal_inference_service.py` | 当前 `answer_text()` 只接 `question/persona`      | 扩展 `memory_context` 参数                                   |
| `model-service/app/services/model_runtime.py`                | 这里是真正拼 Prompt（提示词）的地方               | 改 `ModelBackend` 协议、`HeuristicModelBackend.answer()`、`PromptModelBackend.answer()` |

------

### 建议新增文件

| 文件                                                      | 作用                                          |
| --------------------------------------------------------- | --------------------------------------------- |
| `backend/app/models/assistant_session.py`                 | 会话主表                                      |
| `backend/app/models/assistant_message.py`                 | 对话消息表                                    |
| `backend/app/repositories/assistant_memory_repository.py` | 记忆相关数据库读写                            |
| `backend/app/services/memory_service.py`                  | 会话记忆/用户记忆/事件记忆编排                |
| `backend/tests/test_assistant_memory_api.py`              | 专门测问答记忆链路，避免把原有 P0~P5 测试搞乱 |

------

### 很可能需要顺手修改的文件

| 文件                                        | 原因                                                         |
| ------------------------------------------- | ------------------------------------------------------------ |
| `backend/app/models/__init__.py`            | 新模型需要导出                                               |
| `backend/app/models/entities.py`            | 如果这里做统一模型聚合，要补导入                             |
| `backend/app/db/init_db.py`                 | 确保新表能自动建表                                           |
| `backend/app/api/v1/endpoints/assistant.py` | 通常不用大改，但如果要补注释、兼容逻辑，可能会碰一下         |
| `backend/tests/test_p0_regression.py`       | 如果 `/assistant` 响应字段发生非破坏性新增，最好补一下兼容测试 |

------

### 可选增强，但 V1 可以先不做

这些不是现在必须做的。

| 文件                                              | 现在是否必需 | 说明                                                         |
| ------------------------------------------------- | ------------ | ------------------------------------------------------------ |
| `backend/app/services/knowledge_service.py`       | 否           | 当前知识检索已经够用，V1 不必改                              |
| `backend/app/repositories/incident_repository.py` | 否           | 如果你想把“最近风险事件摘要查询”也复用进来，可以加方法；不想污染它，就放到新 `assistant_memory_repository.py` 里 |
| `backend/app/models/user_profile.py`              | 否           | 已有 `memory_summary` 字段，不需要改表结构                   |
| `backend/app/models/risk_event.py`                | 否           | 已有事件表，不需要改结构                                     |
| `backend/app/models/risk_input_record.py`         | 否           | 已有 OCR/ASR/原始输入字段，可直接读                          |
| `backend/app/models/risk_analysis_result.py`      | 否           | 已有 `analysis_summary / decision_reason / similarity_case_ids / law_ref_ids`，足够做事件摘要来源 |

------

### 我建议的最终落地边界

为了避免项目越改越大，V1 请你只做到下面这个边界：

#### 做

- `/api/v1/assistant` 支持按 `user_id + session_id` 关联上下文
- 记住最近 6~8 条消息
- 从 `user_profile.memory_summary` 拿长期摘要
- 从最近 `risk_event` 拿 2~3 条事件摘要
- 把这些拼进模型 Prompt
- 回答后回写消息，并定期更新 `memory_summary`

#### 不做

- 不改前端页面
- 不立刻上 `pgvector`
- 不做复杂多 Agent（多智能体）编排
- 不做无限历史注入
- 不做全量用户隐私长期保存

这和你项目文档本身也是一致的：当前产品主路径就是“用户主动触发问答/识别”，V1 重点是文本主链稳定、知识检索增强、个性化风险评估、事件沉淀与闭环。

------

### 一句话版文件清单

#### 必改

- `backend/app/schemas/assistant.py`
- `backend/app/services/assistant_service.py`
- `backend/app/services/model_gateway.py`
- `backend/app/dependencies.py`
- `model-service/app/schemas.py`
- `model-service/app/api/v1/endpoints/runtime.py`
- `model-service/app/services/multimodal_inference_service.py`
- `model-service/app/services/model_runtime.py`

#### 新增

- `backend/app/models/assistant_session.py`
- `backend/app/models/assistant_message.py`
- `backend/app/repositories/assistant_memory_repository.py`
- `backend/app/services/memory_service.py`
- `backend/tests/test_assistant_memory_api.py`

#### 可能顺手改

- `backend/app/models/__init__.py`
- `backend/app/models/entities.py`
- `backend/app/db/init_db.py`
- `backend/app/api/v1/endpoints/assistant.py`
- `backend/tests/test_p0_regression.py`

------

### 为什么这样改最稳

因为你现在的产品形态本来就强调：

- 问答入口
- 风险记录沉淀
- 个性化防护
- 监护人联动
- 知识检索增强
- 对话历史存储与检索

而数据库里已经有：

- `user_profile.memory_summary`
- `risk_event`
- `risk_input_record`
- `risk_analysis_result`
- `fraud_knowledge`

所以最省事的路线不是新开一套“记忆系统”，而是**把现有表真正用起来**。

------

### 论文/方案写法建议

如果你后面要把这部分写进答辩材料或方案书，可以这样表述：

> 在现有反诈问答链路中，引入用户上下文记忆编排机制。系统在不改动前端交互的前提下，于后端侧融合短期会话历史、长期用户画像摘要以及近期风险事件摘要，将其统一组织为结构化上下文并注入大模型推理提示中，从而提升问答的连续性、个性化程度与历史一致性。该机制采用“限量历史 + 摘要持久化”的轻量实现方案，兼顾响应性能、可解释性与隐私控制，为后续接入向量检索记忆与知识增强问答提供可扩展基础。

------

### 这次你能学到什么 / 对未来有什么帮助

这次最重要的收获是：
**“有记忆的 AI 问答”本质上是后端架构问题，不是单纯模型问题。** 🧠

模型像一个临时顾问，后端像秘书：
秘书先把“这个用户是谁、刚聊了什么、之前出过什么事”整理成一页纸，再递给顾问。顾问看起来像“记住了”，其实是后端在帮它翻档案。📁

你把这套链路做通之后，以后做：

- 智能客服
- 学习助手
- 风控系统
- 推荐系统
- 多轮问答系统

都会更有感觉。🚀

------

### 当前总体任务进度

**当前阶段：后端改造准备阶段**

已完成：

- 明确了只改后端的实现边界
- 给出了可直接投喂 Codex 的强约束提示词
- 给出了新增/修改文件清单
- 明确了哪些文件必改、哪些先别动

下一步最合适做的事：

- 先把这份提示词交给 Codex 跑一版
- 然后把 Codex 改出来的文件列表和 diff（差异）贴给我
- 我再帮你做第二轮“代码审查 + 精简 + 防叠层”