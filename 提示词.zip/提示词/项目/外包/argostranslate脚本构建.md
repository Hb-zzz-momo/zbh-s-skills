你现在是“Python 工程开发助手 + 本地离线翻译脚本实现助手 + JSON 数据处理工程师”。

### 任务目标
为我生成一个“完整可运行的单文件 Python 脚本”，使用 argostranslate 对 JSON 文件进行离线翻译。

注意：
这里的“翻译 JSON”不是翻译 JSON 键名，也不是破坏 JSON 结构重新生成，
而是：
- 保持原 JSON 结构不变
- 保持 key（字段名）不变
- 只翻译 JSON 中符合规则的英文自然语言字符串值
- 把这些字符串翻译成中文
- 其余值保持原样不变

---

### 核心要求
必须使用 argostranslate 作为唯一翻译引擎。
不允许使用：
- OpenAI API
- Google 翻译 API
- 百度翻译 API
- 任何在线云翻译服务

只允许使用本地离线 Argos Translate。

---

### 正确认知
Argos Translate 只能翻译“文本”，不能直接理解 JSON 结构。
所以请你实现的是：
- Python 负责读取和递归遍历 JSON
- should_translate(...) 负责判定某个值是否需要翻译
- argostranslate 负责翻译被判定为“英文自然语言文本”的字符串
- 最后输出新的 JSON 文件

---

### 翻译判定规则
请实现：

should_translate(value, key_path, field_name)

默认只翻译英文自然语言文本，例如：
- 句子
- 段落
- 对话文本
- 较长说明文本

默认跳过：
- 空字符串
- 数字
- 布尔值
- null
- URL
- 邮箱
- 文件路径
- 文件名
- UUID
- hash
- token
- slug
- 日期
- 时间戳
- 枚举代码
- ID 风格值
- 很短且疑似标签的字符串，例如 agent_1、FS1、turn_001、A12

---

### should_translate 细化要求

#### 一、直接跳过的值类型
- None
- int
- float
- bool
- 空字符串

#### 二、直接跳过的字符串模式
- URL
- 邮箱
- Windows 文件路径
- Linux 文件路径
- 常见文件名（如 .json .txt .pdf .docx .png .jpg .zip）
- UUID
- 长十六进制串
- hash/token 风格字符串
- 日期
- ISO datetime
- Unix 时间戳
- snake_case
- kebab-case
- 全大写代码值
- 带编号标签
- 明显主键或标识符

#### 三、字段名黑名单
这些字段即使值是字符串，也默认不翻译：
- id
- uuid
- uid
- guid
- token
- access_token
- refresh_token
- slug
- code
- status
- type
- path
- file
- filename
- file_name
- url
- uri
- link
- href
- article_url
- email
- hash
- md5
- sha1
- sha256
- timestamp
- created_at
- updated_at
- date
- time
- agent
- agent_id
- turn_id
- message_id
- conversation_id
- case_id
- record_id
- knowledge_source
- turn_rating
- config
- conversation_rating

#### 四、字段名白名单
这些字段更可能是自然语言，可适当放宽判定：
- message
- text
- content
- body
- description
- summary
- title
- question
- answer
- remark
- comment
- caption
- transcript
- dialogue

#### 五、自然语言判定原则
只有明显像英文自然语言时才翻译，例如：
- 至少多个英文单词
- 有英文句子结构
- 有标点
- 是较长的说明文本
- 不是短标签
- 不是枚举值
- 不是评级代码
- 不是情绪标签代码

以下值不要翻译：
- agent_1
- FS1
- turn_001
- A12
- Good
- Bad
- pass
- happy
- surprised
- poor
- excellent

以下值应该翻译：
- Did you know that the University of Iowa's locker room is painted pink?
- Curious to dive deeper?
- This article explains the historical reason behind the design choice.

---

### 脚本功能要求
请生成一个完整的单文件 Python 脚本，例如文件名：
translate_json_argos.py

脚本必须包含以下函数：
1. should_translate(value, key_path, field_name)
2. ensure_argos_model(from_code="en", to_code="zh")
3. translate_text(text, from_code="en", to_code="zh")
4. walk_and_translate(data, key_path="root", field_name="")
5. main()

---

### Argos 模型要求
脚本必须自动处理 Argos Translate 模型的安装和检测逻辑。

要求：
1. 检查 argostranslate 是否已安装
2. 检查是否已存在 en -> zh 模型
3. 若不存在，则自动尝试：
   - update_package_index()
   - get_available_packages()
   - 查找 from_code == "en" 且 to_code == "zh" 的包
   - download()
   - install_from_path(...)
4. 若仍失败，给出清晰报错，不要静默失败

---

### JSON 处理要求
必须支持：
- 读取输入 JSON 文件
- 递归遍历 dict
- 递归遍历 list
- 对每个字符串值执行 should_translate(...)
- 仅翻译应翻译的值
- 输出新的 JSON 文件

输出时必须满足：
- UTF-8 编码
- ensure_ascii=False
- indent=2
- 不改变 key
- 不改变数组顺序
- 不改变数值类型
- 不把 None 变成字符串
- 不破坏原始层级结构

---

### 命令行要求
请使用 argparse（命令行参数解析库）实现命令行参数，支持：

- --input 输入 JSON 文件路径
- --output 输出 JSON 文件路径
- --from-lang 源语言，默认 en
- --to-lang 目标语言，默认 zh
- --debug 是否开启调试日志

示例：
python translate_json_argos.py --input test_freq.json --output test_freq_zh.json --from-lang en --to-lang zh --debug

---

### debug 模式要求
如果传入 --debug，则打印以下内容：
- 当前 key_path
- field_name
- 原始值前 80 个字符
- should_translate 判定结果
- 翻译是否成功

这样方便排查误翻和漏翻。

---

### 异常处理要求
代码必须有完善异常处理：
- 输入文件不存在时，清晰报错
- JSON 解析失败时，清晰报错
- Argos 模型下载失败时，清晰报错
- 翻译失败时，保留原文，不让程序崩溃
- 单条翻译失败不能导致整个任务失败

---

### 代码风格要求
- 必须给完整可运行代码
- 不允许只给伪代码
- 不允许只给函数片段
- 不允许省略 import
- 注释清晰
- 函数边界明确
- 兼容 Python 3.10 或 3.11
- 尽量避免过度依赖复杂第三方框架

---

### 输出格式要求
请严格按以下结构输出：

1. 完整 Python 代码
2. 依赖安装命令
3. 运行说明
4. 最小可运行示例
5. 已知局限与注意事项
6. 自检清单

---

### 最终自检要求
在输出前，请自检以下问题：
- 是否真的使用了 argostranslate
- 是否真的实现了 should_translate
- 是否真的保持 JSON 结构不变
- 是否真的不会翻译 key
- 是否真的不会翻译 URL/ID/文件路径/标签值
- 是否真的支持命令行参数
- 是否真的包含异常处理
- 是否真的能输出 UTF-8 JSON 文件
- 是否真的不是伪代码

请开始生成，不要解释流程，直接按要求输出完整结果。