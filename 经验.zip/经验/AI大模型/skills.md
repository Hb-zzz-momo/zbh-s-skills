- **收集反馈 → 诊断根因 → 提出修改方案 → 用户确认 → 写入 [SKILL.md](vscode-file://vscode-app/d:/newapp/Microsoft VS Code/41dd792b5e/resources/app/out/vs/code/electron-browser/workbench/workbench.html) → 记录 `references/iteration-log.md`**。

- **应该有迭代优化的功能**

- **应该要生成一个总体的skillsREADME作为一个注册清单**